from django.apps import AppConfig


class MybotvkConfig(AppConfig):
    name = 'myBotVK'
